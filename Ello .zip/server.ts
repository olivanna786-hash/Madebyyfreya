import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import multer from 'multer';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

const DATA_DIR = path.join(__dirname, 'data');
const UPLOADS_DIR = path.join(__dirname, 'uploads');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req: any, file: any, cb: any) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req: any, file: any, cb: any) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, `art-${uniqueSuffix}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit
  fileFilter: (req: any, file: any, cb: any) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files (JPG, PNG, WebP) are allowed!'));
    }
  },
});

const DB_FILE = path.join(DATA_DIR, 'database.json');

interface ServerDB {
  artworks: any[];
  homepageArt?: any;
}

function loadDB(): ServerDB {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      const data = JSON.parse(raw);
      return { artworks: data.artworks || [], homepageArt: data.homepageArt || null };
    }
  } catch (err) {
    console.error('Error reading database.json:', err);
  }
  return { artworks: [], homepageArt: null };
}

function saveDB(db: ServerDB): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing database.json:', err);
  }
}

app.use('/uploads', express.static(UPLOADS_DIR));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Homepage Art API Routes
app.get('/api/homepage-art', (req, res) => {
  const db = loadDB();
  res.json({ success: true, homepageArt: db.homepageArt || null });
});

app.post('/api/homepage-art', upload.single('imageFile'), (req, res) => {
  try {
    const body = req.body;
    const file = (req as any).file;
    let imageUrl = body.imageUrl;
    if (file) {
      imageUrl = `/uploads/${file.filename}`;
    }
    const db = loadDB();
    const current = db.homepageArt || {};
    const targetType = body.targetType;

    db.homepageArt = {
      heroImageUrl: targetType === 'hero' && imageUrl ? imageUrl : (body.heroImageUrl !== undefined ? body.heroImageUrl : current.heroImageUrl),
      featuredTitle: body.featuredTitle !== undefined ? body.featuredTitle : current.featuredTitle,
      featuredDescription: body.featuredDescription !== undefined ? body.featuredDescription : current.featuredDescription,
      featuredCategory: body.featuredCategory !== undefined ? body.featuredCategory : current.featuredCategory,
      featuredImageUrl: targetType === 'featured' && imageUrl ? imageUrl : (imageUrl && !targetType ? imageUrl : (body.featuredImageUrl !== undefined ? body.featuredImageUrl : current.featuredImageUrl)),
      updatedAt: new Date().toISOString(),
    };

    saveDB(db);
    res.json({ success: true, homepageArt: db.homepageArt });
  } catch (err: any) {
    console.error('Error saving homepage art:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Artworks API Routes
app.get('/api/artworks', (req, res) => {
  const db = loadDB();
  res.json({ success: true, artworks: db.artworks });
});

app.post('/api/artworks', upload.single('imageFile'), (req, res) => {
  try {
    const body = req.body;
    const file = (req as any).file;
    let imageUrl = body.imageUrl;
    if (file) {
      imageUrl = `/uploads/${file.filename}`;
    }
    if (!body || (!body.id && !body.title)) {
      return res.status(400).json({ success: false, error: 'Invalid artwork data' });
    }
    const artId = body.id || `art_custom_${Date.now()}`;
    const db = loadDB();
    
    const newArt = {
      id: artId,
      title: body.title || 'Custom Artwork',
      category: body.category || 'character',
      categoryLabel: body.categoryLabel || 'Character Art',
      description: body.description || '',
      imageUrl: imageUrl || '',
      status: body.status || 'Available for Commission',
      aspectRatio: body.aspectRatio || '3/4',
      published: body.published !== 'false' && body.published !== false,
      order: body.order ? parseInt(body.order, 10) : db.artworks.length,
      createdAt: new Date().toISOString(),
    };

    const existingIndex = db.artworks.findIndex((a) => a.id === artId);
    if (existingIndex >= 0) {
      db.artworks[existingIndex] = {
        ...db.artworks[existingIndex],
        ...newArt,
        imageUrl: imageUrl || db.artworks[existingIndex].imageUrl,
        updatedAt: new Date().toISOString(),
      };
    } else {
      db.artworks.unshift(newArt);
    }

    saveDB(db);
    res.json({ success: true, artwork: newArt });
  } catch (err: any) {
    console.error('Error saving artwork:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/artworks/:id', upload.single('imageFile'), (req, res) => {
  try {
    const { id } = req.params;
    const body = req.body;
    const file = (req as any).file;
    let imageUrl = body.imageUrl;
    if (file) {
      imageUrl = `/uploads/${file.filename}`;
    }
    const db = loadDB();
    const index = db.artworks.findIndex((a) => a.id === id);
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Artwork not found' });
    }

    const updated = {
      ...db.artworks[index],
      title: body.title !== undefined ? body.title : db.artworks[index].title,
      category: body.category !== undefined ? body.category : db.artworks[index].category,
      categoryLabel: body.categoryLabel !== undefined ? body.categoryLabel : db.artworks[index].categoryLabel,
      description: body.description !== undefined ? body.description : db.artworks[index].description,
      status: body.status !== undefined ? body.status : db.artworks[index].status,
      aspectRatio: body.aspectRatio !== undefined ? body.aspectRatio : db.artworks[index].aspectRatio,
      published: body.published !== undefined ? (body.published === true || body.published === 'true') : db.artworks[index].published,
      imageUrl: imageUrl || db.artworks[index].imageUrl,
      updatedAt: new Date().toISOString(),
    };

    db.artworks[index] = updated;
    saveDB(db);
    res.json({ success: true, artwork: updated });
  } catch (err: any) {
    console.error('Error updating artwork:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.patch('/api/artworks/:id/publish', (req, res) => {
  try {
    const { id } = req.params;
    const { published } = req.body;
    const db = loadDB();
    const index = db.artworks.findIndex((a) => a.id === id);
    if (index === -1) {
      return res.status(404).json({ success: false, error: 'Artwork not found' });
    }
    db.artworks[index].published = Boolean(published);
    saveDB(db);
    res.json({ success: true, artwork: db.artworks[index] });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.delete('/api/artworks/:id', (req, res) => {
  try {
    const { id } = req.params;
    const db = loadDB();
    db.artworks = db.artworks.filter((a) => a.id !== id);
    saveDB(db);
    res.json({ success: true, id });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Catch-all for API routes so they never return HTML index.html
app.all('/api/*', (req, res) => {
  res.status(404).json({ success: false, error: `API route ${req.method} ${req.path} not found` });
});

// Commission Form API
app.post('/api/art-commission', (req, res) => {
  try {
    const { name, email, artworkType, description, budget, deadline, referenceUrl } = req.body;
    if (!name || !email || !description) {
      return res.status(400).json({
        success: false,
        error: 'Please fill in required fields (name, email, and description).',
      });
    }
    const newInquiry = {
      id: `comm_${Date.now()}`,
      name,
      email,
      artworkType: artworkType || 'Character Art',
      description,
      budget: budget || 'Flexible',
      deadline: deadline || 'Flexible',
      referenceUrl: referenceUrl || '',
      submittedAt: new Date().toISOString(),
      status: 'pending',
    };
    res.json({
      success: true,
      inquiryId: newInquiry.id,
      message: 'Commission inquiry received successfully! Freya will review your brief.',
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Global JSON error handling middleware
app.use((err: any, req: any, res: any, next: any) => {
  console.error('Express Error Handler:', err);
  const statusCode = err.status || (res.statusCode === 200 ? 500 : res.statusCode) || 500;
  res.status(statusCode).json({
    success: false,
    error: err.message || 'An unexpected server error occurred',
  });
});

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const server = app.listen(port, '0.0.0.0', () => {
    console.log(`Server started on http://0.0.0.0:${port}`);
  });

  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`Port ${port} is already in use, trying port ${port + 1}...`);
      const fallbackServer = app.listen(port + 1, '0.0.0.0', () => {
        console.log(`Server started on http://0.0.0.0:${port + 1}`);
      });
      fallbackServer.on('error', (e) => {
        console.error('Fallback server error:', e);
      });
    } else {
      console.error('Server error:', err);
    }
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
