import React from 'react';
import { Sparkles, Palette, Mail } from 'lucide-react';
import { motion } from 'framer-motion';

interface HeroProps {
  onNavigate: (sectionId: string) => void;
  onOpenUploadModal?: () => void;
  refreshTrigger?: number;
}

export const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <section id="hero" className="relative pt-24 sm:pt-32 pb-8 sm:pb-12 overflow-hidden bg-[#09080e]">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-violet-600/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#161226] border border-violet-500/30 text-violet-300 text-xs font-semibold uppercase tracking-wider mb-4 shadow-md shadow-violet-950/30">
            <Sparkles className="w-3.5 h-3.5 text-violet-400" />
            <span>Digital Artist &amp; Illustrator &bull; MadeByFreya</span>
          </div>

          <h1 className="text-2xl sm:text-4xl md:text-5xl font-extrabold tracking-tight font-display text-white uppercase leading-[1.15] mb-4">
            WELCOME TO MY{' '}
            <span className="bg-gradient-to-r from-violet-400 via-purple-300 to-indigo-300 bg-clip-text text-transparent">
              ART &amp; COMMISSIONS PORTFOLIO
            </span>
          </h1>

          <p className="text-sm sm:text-base text-neutral-300 max-w-xl mx-auto leading-relaxed mb-6">
            I create captivating digital artwork, expressive character illustrations, dark fantasy concepts, and bespoke custom commissions. Explore my gallery below or reach out to bring your vision to life.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onNavigate('art-commissions')}
              className="px-5 py-3 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-violet-700/30 flex items-center gap-2 cursor-pointer"
            >
              <Palette className="w-4 h-4" />
              <span>Explore Art Gallery</span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                const formEl = document.getElementById('commission-inquiry');
                if (formEl) {
                  formEl.scrollIntoView({ behavior: 'smooth' });
                } else {
                  onNavigate('contact');
                }
              }}
              className="px-5 py-3 rounded-2xl bg-[#171329] hover:bg-[#231d3d] border border-violet-500/30 text-neutral-200 hover:text-white font-semibold text-xs transition-all flex items-center gap-2 cursor-pointer"
            >
              <Mail className="w-4 h-4 text-violet-400" />
              <span>Request Commission</span>
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
