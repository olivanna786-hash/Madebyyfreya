import React, { useState, useEffect } from 'react';
import { Palette, Eye, X, ArrowRight, Upload, Trash2, Edit3, EyeOff, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { ARTWORKS } from '../data/portfolioData';
import { Artwork } from '../types';
import {
  getAllArtworks,
  deleteArtwork,
  updateArtworkPublishStatus,
} from '../utils/artStorage';
import { DeleteConfirmModal } from './DeleteConfirmModal';
import { UploadArtModal } from './UploadArtModal';
import { useOwner } from '../context/OwnerContext';

interface ArtGalleryProps {
  onRequestCommission: () => void;
  refreshTrigger?: number;
  onOpenUploadModal: (editItem?: Artwork | null) => void;
}

export const ArtGallery: React.FC<ArtGalleryProps> = ({
  onRequestCommission,
  refreshTrigger,
  onOpenUploadModal,
}) => {
  const { isOwner, showToast } = useOwner();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeLightbox, setActiveLightbox] = useState<Artwork | null>(null);
  const [artworks, setArtworks] = useState<Artwork[]>([]);
  const [deleteArtTarget, setDeleteArtTarget] = useState<{ id: string; title: string } | null>(null);

  const categories = [
    { id: 'all', label: 'All Artwork' },
    { id: 'character', label: 'Character Art' },
    { id: 'portraits', label: 'Portraits' },
    { id: 'fantasy', label: 'Fantasy & Gothic' },
    { id: 'commissions', label: 'Custom Commissions' },
  ];

  const loadArtworks = async () => {
    try {
      const stored = await getAllArtworks();
      if (stored && stored.length > 0) {
        setArtworks(stored);
      } else {
        setArtworks(ARTWORKS);
      }
    } catch (err) {
      console.warn('Failed to load artworks:', err);
      setArtworks(ARTWORKS);
    }
  };

  useEffect(() => {
    loadArtworks();
  }, [refreshTrigger]);

  const handleTogglePublish = async (art: Artwork, e: React.MouseEvent) => {
    e.stopPropagation();
    const nextStatus = !art.published;
    try {
      await updateArtworkPublishStatus(art.id, nextStatus);
      setArtworks((prev) =>
        prev.map((a) => (a.id === art.id ? { ...a, published: nextStatus } : a))
      );
      showToast(`Artwork "${art.title}" is now ${nextStatus ? 'Published' : 'Unpublished'}.`);
    } catch (err) {
      showToast('Failed to update publication status.');
    }
  };

  const handleConfirmDeleteArtwork = async () => {
    if (!deleteArtTarget) return;
    const { id, title } = deleteArtTarget;
    try {
      await deleteArtwork(id);
      setArtworks((prev) => prev.filter((a) => a.id !== id));
      if (activeLightbox?.id === id) {
        setActiveLightbox(null);
      }
      showToast(`Artwork "${title}" deleted successfully.`);
    } catch (err) {
      console.error('Error deleting artwork:', err);
      showToast('Could not delete artwork.');
    } finally {
      setDeleteArtTarget(null);
    }
  };

  const displayArtworks = isOwner
    ? artworks
    : artworks.filter((art) => art.published !== false);

  const filteredArtworks = activeCategory === 'all'
    ? displayArtworks
    : displayArtworks.filter((art) => art.category === activeCategory);

  return (
    <section id="art-commissions" className="pt-12 sm:pt-16 pb-20 sm:pb-28 relative bg-[#0b0913] border-t border-[#1f1b2e]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#171426] border border-violet-500/30 text-violet-300 text-xs font-semibold uppercase tracking-wider mb-3">
              <Palette className="w-3.5 h-3.5 text-violet-400" />
              <span>Digital Art Gallery</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight font-display text-white mb-3">
              ART THAT TELLS YOUR STORY
            </h2>
            <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
              Custom digital illustration and character art created with meticulous detail and intention.
              Explore available pieces or request a bespoke commission.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            {isOwner && (
              <button
                type="button"
                onClick={() => onOpenUploadModal(null)}
                className="px-5 py-2.5 rounded-2xl bg-[#19152b] hover:bg-[#251f3e] border border-violet-500/40 text-violet-300 hover:text-white font-semibold text-xs transition-all flex items-center gap-2 cursor-pointer shadow-md min-h-[44px]"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Artwork</span>
              </button>
            )}
            <button
              type="button"
              onClick={onRequestCommission}
              className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-violet-700/30 flex items-center gap-2 cursor-pointer hover:scale-102 active:scale-98 min-h-[44px]"
            >
              <span>REQUEST A COMMISSION</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-10">
          <div className="flex flex-wrap items-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveCategory(cat.id)}
                className={`px-4 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                    : 'bg-[#151222] text-neutral-300 hover:text-white hover:bg-[#1d1930] border border-[#27213d]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
          {isOwner && (
            <span className="text-xs text-violet-300 bg-violet-950/40 px-3 py-1 rounded-full border border-violet-500/30">
              Owner Mode: Tap <strong>Edit</strong> or <strong>Delete</strong> on any artwork card
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredArtworks.map((art, index) => {
            const isUnpublished = art.published === false;
            return (
              <motion.div
                key={art.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.4, delay: index * 0.06 }}
                whileHover={{ y: -4 }}
                className={`group rounded-3xl overflow-hidden bg-[#120f1e] border transition-all duration-300 flex flex-col shadow-xl relative ${
                  isUnpublished ? 'border-amber-500/50 opacity-80' : 'border-[#252038] hover:border-violet-500/50'
                }`}
              >
                <div
                  onClick={() => setActiveLightbox(art)}
                  className="relative aspect-[4/5] w-full overflow-hidden bg-black cursor-pointer"
                >
                  <img
                    src={art.imageUrl}
                    alt={art.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent opacity-60 group-hover:opacity-90 transition-opacity" />
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-black/70 backdrop-blur-sm text-[10px] font-bold text-violet-300 uppercase tracking-wider border border-white/10 z-10">
                    {art.categoryLabel}
                  </div>
                  {isUnpublished && (
                    <div className="absolute top-3 right-16 px-2.5 py-1 rounded-md bg-amber-950/90 text-amber-300 text-[10px] font-bold border border-amber-500/50 z-20">
                      Unpublished
                    </div>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10 pointer-events-none">
                    <div className="w-12 h-12 rounded-full bg-violet-600/90 text-white flex items-center justify-center shadow-xl">
                      <Eye className="w-5 h-5" />
                    </div>
                  </div>
                </div>

                {/* Owner Action Buttons */}
                {isOwner && (
                  <div className="absolute top-3 right-3 z-40 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={(e) => handleTogglePublish(art, e)}
                      className={`min-w-[36px] min-h-[36px] rounded-xl flex items-center justify-center transition-all shadow-md cursor-pointer ${
                        art.published === false
                          ? 'bg-amber-950 text-amber-300 border border-amber-500/60 hover:bg-amber-900'
                          : 'bg-[#1a142c] text-emerald-300 border border-emerald-500/40 hover:bg-[#251e3e]'
                      }`}
                      title={art.published === false ? 'Publish Artwork' : 'Unpublish Artwork'}
                    >
                      {art.published === false ? <EyeOff className="w-4 h-4" /> : <CheckCircle className="w-4 h-4" />}
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenUploadModal(art);
                      }}
                      className="min-w-[36px] min-h-[36px] rounded-xl bg-violet-950/95 hover:bg-violet-600 text-violet-200 hover:text-white border border-violet-500/60 flex items-center justify-center transition-all shadow-md cursor-pointer"
                      title="Edit Artwork"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setDeleteArtTarget({ id: art.id, title: art.title });
                      }}
                      className="min-w-[36px] min-h-[36px] rounded-xl bg-red-950/95 hover:bg-red-600 text-red-200 hover:text-white border border-red-500/60 flex items-center justify-center transition-all shadow-md cursor-pointer"
                      title="Delete Artwork"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}

                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3
                      onClick={() => setActiveLightbox(art)}
                      className="text-base font-bold text-white group-hover:text-violet-300 transition-colors mb-1.5 cursor-pointer"
                    >
                      {art.title}
                    </h3>
                    <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed mb-4">
                      {art.description}
                    </p>
                  </div>
                  <div className="pt-3 border-t border-[#1e1a2f] flex items-center justify-between">
                    <span className="text-[11px] font-medium text-emerald-400 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      {art.status}
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveLightbox(art)}
                      className="text-xs text-violet-400 hover:text-violet-300 font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <span>View</span>
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Lightbox Modal */}
        {activeLightbox && (
          <div
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200"
            onClick={() => setActiveLightbox(null)}
          >
            <div
              className="relative max-w-4xl max-h-[90vh] bg-[#120f1e] rounded-3xl overflow-hidden border border-[#2d2545] shadow-2xl flex flex-col md:flex-row"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={() => setActiveLightbox(null)}
                className="absolute top-4 right-4 z-20 p-2 rounded-xl bg-black/60 hover:bg-black text-neutral-300 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="md:w-3/5 bg-black flex items-center justify-center p-2 max-h-[60vh] md:max-h-[85vh] overflow-hidden">
                <img
                  src={activeLightbox.imageUrl}
                  alt={activeLightbox.title}
                  className="max-h-full max-w-full object-contain"
                />
              </div>
              <div className="md:w-2/5 p-6 sm:p-8 flex flex-col justify-between bg-[#151126] border-t md:border-t-0 md:border-l border-[#27203b]">
                <div>
                  <span className="text-[10px] font-bold text-violet-300 uppercase tracking-widest px-2.5 py-1 rounded-md bg-[#1e1834] border border-violet-500/20 inline-block mb-3">
                    {activeLightbox.categoryLabel}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-bold font-display text-white mb-2">
                    {activeLightbox.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mb-6">
                    {activeLightbox.description}
                  </p>
                </div>
                <div className="pt-6 border-t border-[#231c34] space-y-3">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Commission Status:</span>
                    <span className="text-emerald-400 font-semibold">{activeLightbox.status}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveLightbox(null);
                      onRequestCommission();
                    }}
                    className="w-full py-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-violet-700/30 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Request Artwork Like This</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        <DeleteConfirmModal
          isOpen={!!deleteArtTarget}
          onClose={() => setDeleteArtTarget(null)}
          onConfirm={handleConfirmDeleteArtwork}
          itemTitle={deleteArtTarget?.title || 'this artwork'}
          itemType="artwork"
        />
      </div>
    </section>
  );
};
