import React, { useState } from 'react';
import { X, KeyRound, AlertCircle, Unlock } from 'lucide-react';
import { useOwner } from '../context/OwnerContext';

export const OwnerLoginModal: React.FC = () => {
  const { isLoginModalOpen, closeLoginModal, enableOwner } = useOwner();
  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  if (!isLoginModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const success = enableOwner(pin);
    if (!success) {
      setError('Incorrect PIN. Please try again.');
    } else {
      setPin('');
    }
  };

  return (
    <div
      className="fixed inset-0 z-[95] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-150"
      onClick={closeLoginModal}
    >
      <div
        className="relative w-full max-w-sm bg-[#131022] rounded-3xl border border-violet-500/50 shadow-2xl p-6 sm:p-7 text-left"
        onClick={(e) => e.stopPropagation()}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="w-11 h-11 rounded-2xl bg-violet-600/25 text-violet-300 flex items-center justify-center border border-violet-500/40">
            <KeyRound className="w-5 h-5 text-violet-400" />
          </div>
          <button
            type="button"
            onClick={closeLoginModal}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <h3 className="text-lg font-bold text-white mb-1.5 font-display flex items-center gap-2">
          <span>Creator Studio Access</span>
          <span className="w-2 h-2 rounded-full bg-violet-500 animate-pulse" />
        </h3>
        <p className="text-xs text-neutral-300 leading-relaxed mb-5">
          Enter your confidential Creator PIN to unlock gallery management controls.
        </p>

        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Creator Studio PIN
            </label>
            <input
              type="password"
              autoFocus
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="Enter PIN"
              className="w-full px-4 py-3 rounded-xl bg-[#0c0a15] border border-[#2b2444] text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500 font-mono tracking-widest text-center"
            />
          </div>
          <div className="pt-1">
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-violet-700/30 flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
            >
              <Unlock className="w-4 h-4" />
              <span>Unlock Creator Controls</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
