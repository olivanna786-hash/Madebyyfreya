import React from 'react';
import { Eye, Upload, KeyRound } from 'lucide-react';
import { useOwner } from '../context/OwnerContext';

interface OwnerBannerProps {
  onOpenUploadModal?: () => void;
}

export const OwnerBanner: React.FC<OwnerBannerProps> = ({ onOpenUploadModal }) => {
  const { isOwner, disableOwner, openChangePinModal } = useOwner();

  if (!isOwner) {
    return null;
  }

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[60] backdrop-blur-xl px-4 py-2.5 rounded-full shadow-2xl flex items-center gap-3 text-xs animate-in slide-in-from-bottom-3 duration-200 border transition-all duration-300 bg-[#141026]/95 border-violet-500/60 shadow-violet-950/80">
      <div className="flex items-center gap-2 text-violet-300 font-medium">
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
        <span className="text-white font-bold hidden sm:inline">Owner Mode:</span>
        <span className="text-neutral-300 hidden md:inline">Upload, Edit &amp; Delete active</span>
      </div>
      <div className="flex items-center gap-2">
        {onOpenUploadModal && (
          <button
            type="button"
            onClick={onOpenUploadModal}
            className="px-3 py-1.5 rounded-full bg-violet-600 hover:bg-violet-500 text-white font-semibold text-[11px] transition-colors flex items-center gap-1 cursor-pointer shadow-md shadow-violet-700/40"
          >
            <Upload className="w-3 h-3" />
            <span>Upload</span>
          </button>
        )}
        <button
          type="button"
          onClick={openChangePinModal}
          className="px-3 py-1.5 rounded-full bg-[#201a38] hover:bg-[#2b224d] text-violet-300 hover:text-white font-semibold text-[11px] transition-colors flex items-center gap-1 cursor-pointer border border-violet-500/30"
          title="Change PIN"
        >
          <KeyRound className="w-3 h-3 text-violet-400" />
          <span>Change PIN</span>
        </button>
        <button
          type="button"
          onClick={disableOwner}
          className="px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-neutral-200 hover:text-white font-semibold text-[11px] transition-colors flex items-center gap-1.5 cursor-pointer border border-white/10"
          title="Preview Visitor View"
        >
          <Eye className="w-3.5 h-3.5 text-violet-400" />
          <span>Preview Visitor View</span>
        </button>
      </div>
    </div>
  );
};
