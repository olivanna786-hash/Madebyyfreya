import React from 'react';
import { Palette, Sparkles, User, Wand2, Crown, Shield, ArrowRight } from 'lucide-react';

interface ServicesSectionProps {
  onNavigate: (sectionId: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onNavigate }) => {
  const services = [
    {
      icon: User,
      title: 'Character Illustration',
      desc: 'Bespoke character designs, concept art, and full-body illustrations with meticulous detail, custom lighting, and high resolution.',
    },
    {
      icon: Palette,
      title: 'Portraits & Avatars',
      desc: 'Stylized profile pictures, headshots, and emotional portraits tailored for Twitch streamers, gamers, and VTubers.',
    },
    {
      icon: Wand2,
      title: 'Fantasy & Gothic Art',
      desc: 'Ethereal and dark fantasy landscapes, sorceresses, mythical creatures, and atmospheric concept art.',
    },
    {
      icon: Crown,
      title: 'Custom Book & Album Cover Art',
      desc: 'Commercial-grade illustrations designed to capture listeners or readers instantly with striking visual storytelling.',
    },
    {
      icon: Shield,
      title: 'Gaming Mascots & Logos',
      desc: 'Bold esports logos, clan insignias, and character mascots engineered for maximum visual impact across platforms.',
    },
    {
      icon: Sparkles,
      title: 'Concept Art & Moodboards',
      desc: 'Visual development for indie game projects, tabletop campaigns, and narrative storyboards.',
    },
  ];

  return (
    <section id="services" className="py-20 sm:py-28 relative bg-[#0c0a15] border-t border-[#1d192c]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#181527] border border-violet-500/30 text-violet-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-violet-400" />
            <span>Art Commissions &amp; Pricing</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight font-display text-white mb-3">
            SERVICES &amp; COMMISSION TIERS
          </h2>
          <p className="text-neutral-400 text-sm sm:text-base leading-relaxed">
            Every artwork is custom-crafted to your specifications. Pricing depends on complexity, rendering style, and commercial rights.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((svc, idx) => {
            const Icon = svc.icon;
            return (
              <div
                key={idx}
                className="p-7 rounded-3xl bg-[#120f1e] border border-[#231f36] hover:border-violet-500/40 transition-all duration-300 flex flex-col justify-between group hover:shadow-xl hover:shadow-violet-950/20"
              >
                <div>
                  <div className="w-12 h-12 rounded-2xl bg-violet-600/20 text-violet-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform border border-violet-500/20">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2 font-display group-hover:text-violet-300 transition-colors">
                    {svc.title}
                  </h3>
                  <p className="text-xs text-neutral-400 leading-relaxed mb-6">
                    {svc.desc}
                  </p>
                </div>
                <div className="pt-4 border-t border-[#1e1a2c]">
                  <button
                    onClick={() => onNavigate('commission-inquiry')}
                    className="text-xs font-semibold text-violet-400 hover:text-violet-300 flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <span>Request This Service</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
