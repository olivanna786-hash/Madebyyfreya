import React, { useState } from 'react';
import { Send, CheckCircle, AlertCircle, RefreshCw, Mail, Sparkles, Copy, Check } from 'lucide-react';
import { CommissionFormData } from '../types';

export const CommissionForm: React.FC = () => {
  const [formData, setFormData] = useState<CommissionFormData>({
    name: '',
    email: '',
    artworkType: 'Character Art',
    description: '',
    budget: '$250 - $500',
    deadline: 'Within 2-3 weeks',
    referenceUrl: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submittedBrief, setSubmittedBrief] = useState<CommissionFormData | null>(null);
  const [copiedBrief, setCopiedBrief] = useState<boolean>(false);

  const artworkTypes = [
    'Character Art',
    'Portraits',
    'Fantasy & Gothic',
    'Custom Commissions',
    'Gaming Mascot / Twitch Avatar',
    'Album / Track Cover Art',
  ];

  const budgetOptions = [
    'Under $150',
    '$150 - $300',
    '$300 - $600',
    '$600 - $1,200',
    '$1,200+ (Extensive Project)',
    'Flexible / Discuss with Freya',
  ];

  const deadlineOptions = [
    'Urgent (Under 1 week)',
    'Within 2-3 weeks',
    'Within 1 month',
    'No rush / Quality first',
  ];

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) {
      errs.name = 'Please provide your name or username.';
    }
    if (!formData.email.trim()) {
      errs.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errs.email = 'Please enter a valid email address (e.g. name@example.com).';
    }
    if (!formData.description.trim() || formData.description.trim().length < 15) {
      errs.description = 'Please describe your artwork concept in at least 15 characters.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsSubmitting(true);
    setErrors({});
    try {
      const response = await fetch('/api/art-commission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to submit commission request');
      }
      setSubmittedBrief(formData);
    } catch (err: any) {
      setErrors({ form: err.message || 'Network error occurred. Please try again or email directly.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyBrief = async () => {
    if (!submittedBrief) return;
    const text = `Commission Brief for Freya:\nName: ${submittedBrief.name}\nEmail: ${submittedBrief.email}\nArtwork Type: ${submittedBrief.artworkType}\nBudget: ${submittedBrief.budget}\nDeadline: ${submittedBrief.deadline}\nReference: ${submittedBrief.referenceUrl || 'None'}\nDescription: ${submittedBrief.description}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedBrief(true);
      setTimeout(() => setCopiedBrief(false), 2000);
    } catch {}
  };

  return (
    <div id="commission-inquiry" className="max-w-4xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#181427] border border-violet-500/30 text-violet-300 text-xs font-semibold uppercase tracking-wider mb-3">
          <Sparkles className="w-3.5 h-3.5 text-violet-400" />
          <span>Commission Inquiry</span>
        </div>
        <h3 className="text-2xl sm:text-4xl font-extrabold font-display text-white mb-2">
          LET&apos;S CREATE SOMETHING PERSONAL
        </h3>
        <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
          Have an idea in mind? Tell me what you&apos;re imagining, and let&apos;s turn it into a custom piece of digital art.
        </p>
      </div>

      {submittedBrief ? (
        <div className="p-8 rounded-3xl bg-[#141122] border border-emerald-500/40 text-center animate-in fade-in duration-300 shadow-2xl">
          <div className="w-16 h-16 rounded-full bg-emerald-600/20 text-emerald-400 flex items-center justify-center mx-auto mb-4 border border-emerald-500/30">
            <CheckCircle className="w-8 h-8" />
          </div>
          <h4 className="text-xl font-bold text-white mb-2 font-display">
            Commission Request Received!
          </h4>
          <p className="text-sm text-neutral-300 max-w-lg mx-auto mb-6 leading-relaxed">
            Thank you, <span className="text-white font-semibold">{submittedBrief.name}</span>. Your brief has been securely registered. Freya will review the scope and reply to <span className="text-violet-300 font-semibold">{submittedBrief.email}</span> within 24-48 hours.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleCopyBrief}
              className="px-5 py-2.5 rounded-xl bg-[#1c182d] hover:bg-[#25203c] border border-[#352d51] text-xs font-semibold text-white flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copiedBrief ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-neutral-300" />}
              <span>{copiedBrief ? 'Brief Copied!' : 'Copy Brief to Clipboard'}</span>
            </button>
            <a
              href={`mailto:freyaaly786@gmail.com?subject=Art Commission Inquiry: ${encodeURIComponent(submittedBrief.artworkType)} - ${encodeURIComponent(submittedBrief.name)}&body=${encodeURIComponent(
                `Hello Freya,\n\nI just submitted a commission brief on your site:\n\nType: ${submittedBrief.artworkType}\nBudget: ${submittedBrief.budget}\nDeadline: ${submittedBrief.deadline}\nDescription:\n${submittedBrief.description}\n\nLooking forward to working together!`
              )}`}
              className="px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-semibold text-white flex items-center gap-1.5 transition-colors shadow-lg shadow-violet-700/30"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Open in Email App (freyaaly786@gmail.com)</span>
            </a>
            <button
              onClick={() => {
                setSubmittedBrief(null);
                setFormData({
                  name: '',
                  email: '',
                  artworkType: 'Character Art',
                  description: '',
                  budget: '$250 - $500',
                  deadline: 'Within 2-3 weeks',
                  referenceUrl: '',
                });
              }}
              className="px-4 py-2.5 rounded-xl text-neutral-400 hover:text-white text-xs transition-colors"
            >
              Submit Another Request
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="p-6 sm:p-10 rounded-3xl bg-[#131021] border border-[#27213b] shadow-2xl space-y-6">
          {errors.form && (
            <div className="p-4 rounded-2xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errors.form}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Your Name or Username <span className="text-violet-400">*</span>
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. Alex M. or @nightraven"
                className={`w-full px-4 py-3 rounded-xl bg-[#0c0a15] border text-xs text-white placeholder-neutral-500 focus:outline-none transition-colors ${
                  errors.name ? 'border-red-500 focus:border-red-400' : 'border-[#29233f] focus:border-violet-500'
                }`}
              />
              {errors.name && <p className="text-[11px] text-red-400 mt-1">{errors.name}</p>}
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Email or Preferred Contact <span className="text-violet-400">*</span>
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="e.g. name@example.com"
                className={`w-full px-4 py-3 rounded-xl bg-[#0c0a15] border text-xs text-white placeholder-neutral-500 focus:outline-none transition-colors ${
                  errors.email ? 'border-red-500 focus:border-red-400' : 'border-[#29233f] focus:border-violet-500'
                }`}
              />
              {errors.email && <p className="text-[11px] text-red-400 mt-1">{errors.email}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Type of Artwork
              </label>
              <select
                value={formData.artworkType}
                onChange={(e) => setFormData({ ...formData, artworkType: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-[#0c0a15] border border-[#29233f] text-xs text-white focus:outline-none focus:border-violet-500"
              >
                {artworkTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Budget Range
              </label>
              <select
                value={formData.budget}
                onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-[#0c0a15] border border-[#29233f] text-xs text-white focus:outline-none focus:border-violet-500"
              >
                {budgetOptions.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Preferred Deadline
              </label>
              <select
                value={formData.deadline}
                onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-[#0c0a15] border border-[#29233f] text-xs text-white focus:outline-none focus:border-violet-500"
              >
                {deadlineOptions.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Description of Requested Artwork <span className="text-violet-400">*</span>
            </label>
            <textarea
              rows={4}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Tell me about your character, visual theme, mood, color preferences, poses, or storytelling elements..."
              className={`w-full px-4 py-3 rounded-xl bg-[#0c0a15] border text-xs text-white placeholder-neutral-500 focus:outline-none transition-colors ${
                errors.description ? 'border-red-500 focus:border-red-400' : 'border-[#29233f] focus:border-violet-500'
              }`}
            />
            {errors.description && <p className="text-[11px] text-red-400 mt-1">{errors.description}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Reference Image or Moodboard Link (Optional)
            </label>
            <input
              type="text"
              value={formData.referenceUrl}
              onChange={(e) => setFormData({ ...formData, referenceUrl: e.target.value })}
              placeholder="e.g. Pinterest board, Imgur link, or Google Drive folder"
              className="w-full px-4 py-3 rounded-xl bg-[#0c0a15] border border-[#29233f] text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wider shadow-xl shadow-violet-700/30 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed hover:scale-[1.01] active:scale-[0.99]"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>SENDING COMMISSION REQUEST...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>SEND COMMISSION REQUEST</span>
                </>
              )}
            </button>
            <p className="text-center text-[11px] text-neutral-500 mt-3">
              Direct inbox delivery to <span className="text-neutral-400 font-mono">freyaaly786@gmail.com</span>
            </p>
          </div>
        </form>
      )}
    </div>
  );
};
