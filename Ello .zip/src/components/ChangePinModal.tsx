import React, { useState } from 'react';
import { KeyRound, X, AlertCircle, ShieldCheck } from 'lucide-react';
import { useOwner } from '../context/OwnerContext';

interface ChangePinModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ChangePinModal: React.FC<ChangePinModalProps> = ({ isOpen, onClose }) => {
  const { changePin } = useOwner();
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!newPin.trim()) {
      setError('Please enter a new PIN.');
      return;
    }
    if (newPin.trim().length < 2) {
      setError('PIN must be at least 2 characters long.');
      return;
    }
    if (newPin !== confirmPin) {
      setError('New PIN and confirmation PIN do not match.');
      return;
    }
    const success = changePin(newPin);
    if (success) {
      setNewPin('');
      setConfirmPin('');
      onClose();
    } else {
      setError('Failed to update PIN. Please try again.');
    }
  };

  return (
    <div
      className="fixed inset-0 z-[96] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-sm bg-[#131022] rounded-3xl border border-violet-500/50 shadow-2xl p-6 sm:p-7 text-left"
        onClick={(e) => e.stopPropagation()}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="w-11 h-11 rounded-2xl bg-violet-600/25 text-violet-300 flex items-center justify-center border border-violet-500/40">
            <ShieldCheck className="w-5 h-5 text-violet-400" />
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <h3 className="text-lg font-bold text-white mb-1.5 font-display flex items-center gap-2">
          <span>Change Creator PIN</span>
        </h3>
        <p className="text-xs text-neutral-300 leading-relaxed mb-5">
          Set a new custom PIN for your creator studio access. Make sure to remember it!
        </p>

        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              New PIN
            </label>
            <input
              type="password"
              autoFocus
              value={newPin}
              onChange={(e) => setNewPin(e.target.value)}
              placeholder="Enter new PIN"
              className="w-full px-4 py-3 rounded-xl bg-[#0c0a15] border border-[#2b2444] text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500 font-mono tracking-widest text-center"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Confirm New PIN
            </label>
            <input
              type="password"
              value={confirmPin}
              onChange={(e) => setConfirmPin(e.target.value)}
              placeholder="Re-enter new PIN"
              className="w-full px-4 py-3 rounded-xl bg-[#0c0a15] border border-[#2b2444] text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500 font-mono tracking-widest text-center"
            />
          </div>
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-violet-700/30 flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
            >
              <KeyRound className="w-4 h-4" />
              <span>Save New PIN</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
