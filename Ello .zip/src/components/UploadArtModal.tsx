import React, { useState, useRef, useEffect } from 'react';
import { Palette, Upload, X, CheckCircle, AlertCircle, RefreshCw, Cloud, Image as ImageIcon } from 'lucide-react';
import { Artwork } from '../types';
import { saveArtwork } from '../utils/artStorage';

interface UploadArtModalProps {
  isOpen: boolean;
  onClose: () => void;
  onArtSaved: () => void;
  editTarget?: Artwork | null;
}

export const UploadArtModal: React.FC<UploadArtModalProps> = ({
  isOpen,
  onClose,
  onArtSaved,
  editTarget = null,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<'character' | 'portraits' | 'fantasy' | 'commissions'>('character');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('Available for Commission');
  const [aspectRatio, setAspectRatio] = useState('3/4');
  const [published, setPublished] = useState(true);

  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [previewSrc, setPreviewSrc] = useState<string | null>(null);

  const [isSaving, setIsSaving] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      if (editTarget) {
        setTitle(editTarget.title);
        setCategory(editTarget.category as any);
        setDescription(editTarget.description || '');
        setStatus(editTarget.status || 'Available for Commission');
        setAspectRatio(editTarget.aspectRatio || '3/4');
        setPublished(editTarget.published ?? true);
        setPreviewSrc(editTarget.imageUrl);
        setImageUrlInput(editTarget.imageUrl);
      } else {
        setTitle('');
        setCategory('character');
        setDescription('');
        setStatus('Available for Commission');
        setAspectRatio('3/4');
        setPublished(true);
        setPreviewSrc(null);
        setImageUrlInput('');
      }
      setImageFile(null);
      setError(null);
      setSuccessMessage(null);
      setUploadProgress(0);
    }
  }, [isOpen, editTarget]);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please select a valid image file (JPG, PNG, WebP).');
        return;
      }
      if (file.size > 25 * 1024 * 1024) {
        setError('File size exceeds 25MB limit. Please choose a smaller file.');
        return;
      }
      setError(null);
      setImageFile(file);
      const url = URL.createObjectURL(file);
      setPreviewSrc(url);
      if (!title && !editTarget) {
        const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        setTitle(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
      }
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!title.trim()) {
      setError('Please provide an artwork title.');
      return;
    }
    if (!imageFile && !imageUrlInput.trim() && !previewSrc) {
      setError('Please choose an image file or provide an image URL.');
      return;
    }

    setIsSaving(true);
    setUploadProgress(20);

    try {
      const categoryLabels: Record<string, string> = {
        character: 'Character Art',
        portraits: 'Portraits',
        fantasy: 'Fantasy & Gothic',
        commissions: 'Custom Commission',
      };

      setUploadProgress(60);
      await saveArtwork({
        id: editTarget ? editTarget.id : undefined,
        title: title.trim(),
        category,
        categoryLabel: categoryLabels[category] || 'Digital Art',
        description: description.trim() || 'Custom digital artwork by Freya.',
        imageBlob: imageFile || undefined,
        imageUrl: !imageFile ? imageUrlInput.trim() : undefined,
        status,
        aspectRatio,
        published,
      });

      setUploadProgress(100);
      setSuccessMessage(editTarget ? 'Artwork successfully updated!' : 'Artwork uploaded successfully to gallery!');
      onArtSaved();

      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      console.error('Error saving artwork:', err);
      setError(err.message || 'Failed to save artwork. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-xl bg-[#120f21] rounded-3xl border border-violet-500/40 shadow-2xl p-6 sm:p-8 text-left my-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-[#241e3a] mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-violet-600/20 text-violet-400 flex items-center justify-center border border-violet-500/30">
              <Palette className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold font-display text-white">
                {editTarget ? `Edit Artwork: ${editTarget.title}` : 'Upload New Digital Artwork'}
              </h3>
              <p className="text-xs text-neutral-400 flex items-center gap-1.5 mt-0.5">
                <Cloud className="w-3.5 h-3.5 text-emerald-400" />
                <span>Persistent Server Storage &amp; Gallery Sync</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="p-3.5 mb-5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center gap-2.5">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-3.5 mb-5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2.5">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {isSaving && (
          <div className="mb-5 p-4 rounded-2xl bg-[#161228] border border-violet-500/40 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-white">
              <span className="flex items-center gap-2">
                <RefreshCw className="w-3.5 h-3.5 text-violet-400 animate-spin" />
                <span>Saving artwork to storage...</span>
              </span>
              <span className="font-mono text-violet-300">{uploadProgress}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-black/60 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-violet-600 to-indigo-500 transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Artwork Image File or URL *
            </label>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={handleFileChange}
              className="hidden"
            />
            <div className="flex gap-2 mb-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2.5 rounded-xl bg-[#1e1832] hover:bg-[#282142] text-xs font-medium text-violet-300 border border-violet-500/30 flex items-center gap-2 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{imageFile ? imageFile.name : 'Choose Image File (JPG, PNG, WebP)'}</span>
              </button>
            </div>
            <input
              type="url"
              value={imageUrlInput}
              onChange={(e) => {
                setImageUrlInput(e.target.value);
                if (e.target.value) setPreviewSrc(e.target.value);
              }}
              placeholder="Or paste image URL (https://...)"
              className="w-full px-4 py-2 rounded-xl bg-[#0c0915] border border-[#2b2444] text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500"
            />
          </div>

          {previewSrc && (
            <div className="w-full aspect-[4/3] max-h-48 rounded-2xl overflow-hidden bg-black flex items-center justify-center border border-[#2b2444]">
              <img src={previewSrc} alt="Preview" className="h-full object-contain" />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Artwork Title *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Celestial Sorceress"
              className="w-full px-4 py-2.5 rounded-xl bg-[#0c0915] border border-[#2b2444] text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2.5 rounded-xl bg-[#0c0915] border border-[#2b2444] text-xs text-white focus:outline-none focus:border-violet-500"
              >
                <option value="character">Character Art</option>
                <option value="portraits">Portraits</option>
                <option value="fantasy">Fantasy &amp; Gothic</option>
                <option value="commissions">Custom Commissions</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Status Badge
              </label>
              <input
                type="text"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                placeholder="Available for Commission"
                className="w-full px-3 py-2.5 rounded-xl bg-[#0c0915] border border-[#2b2444] text-xs text-white focus:outline-none focus:border-violet-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Description
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Details about style, medium, theme, inspiration..."
              className="w-full px-4 py-2.5 rounded-xl bg-[#0c0915] border border-[#2b2444] text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <label className="flex items-center gap-2 cursor-pointer text-xs text-neutral-300">
              <input
                type="checkbox"
                checked={published}
                onChange={(e) => setPublished(e.target.checked)}
                className="rounded accent-violet-600"
              />
              <span>Publish immediately to public gallery</span>
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#231b34]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs text-neutral-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-violet-700/35 cursor-pointer disabled:opacity-50"
            >
              {isSaving ? 'Saving Artwork...' : editTarget ? 'Update Artwork' : 'Upload & Publish'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
