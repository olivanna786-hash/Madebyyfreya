import React, { useState, useEffect } from 'react';
import { Palette, User, Mail, Sparkles, Menu, X, Upload, Lock, Unlock, Eye } from 'lucide-react';
import { useOwner } from '../context/OwnerContext';

interface NavbarProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  onOpenUploadModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeSection,
  onNavigate,
  onOpenUploadModal,
}) => {
  const { isOwner, openLoginModal, disableOwner } = useOwner();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'art-commissions', label: 'Art Gallery', icon: Palette, highlight: true },
    { id: 'about', label: 'About Freya', icon: User },
    { id: 'services', label: 'Services', icon: Sparkles },
    { id: 'commission-inquiry', label: 'Commissions', icon: Palette },
    { id: 'contact', label: 'Contact', icon: Mail },
  ];

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#09080e]/95 backdrop-blur-md border-b border-[#221f33] py-3 shadow-xl shadow-black/50'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <button
            onClick={() => handleLinkClick('art-commissions')}
            className="flex items-center gap-2.5 group text-left cursor-pointer focus:outline-none"
            aria-label="MadeByFreya Home"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 to-purple-900 flex items-center justify-center font-bold text-white shadow-lg shadow-violet-600/30 group-hover:scale-105 transition-transform">
              <span className="font-display tracking-wider text-base">F</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg font-bold font-display tracking-tight text-white group-hover:text-violet-300 transition-colors">
                  MadeByFreya
                </span>
                <span className="w-2 h-2 rounded-full bg-violet-500 animate-pulse" />
              </div>
              <p className="text-[10px] tracking-widest uppercase text-violet-400 font-medium">
                Digital Artist &amp; Illustrator
              </p>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1 bg-[#141221]/80 p-1.5 rounded-full border border-[#26223d]/80 backdrop-blur-md">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleLinkClick(item.id)}
                  className={`px-4 py-1.5 rounded-full text-xs font-medium transition-all cursor-pointer flex items-center gap-1.5 ${
                    item.highlight && !isActive
                      ? 'text-violet-300 hover:text-white hover:bg-violet-600/20 border border-violet-500/30'
                      : isActive
                      ? 'bg-violet-600 text-white font-semibold shadow-md shadow-violet-700/30'
                      : 'text-neutral-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Button */}
          <div className="hidden sm:flex items-center gap-3">
            {isOwner ? (
              <>
                <button
                  type="button"
                  onClick={onOpenUploadModal}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 shadow-lg shadow-violet-700/25 transition-all flex items-center gap-1.5 cursor-pointer hover:scale-102 active:scale-98 min-h-[40px]"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload Artwork</span>
                </button>
                <button
                  type="button"
                  onClick={disableOwner}
                  className="px-3 py-2 rounded-xl text-xs font-medium text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-500/40 shadow-sm transition-all flex items-center gap-1.5 cursor-pointer min-h-[40px]"
                  title="Switch to Visitor View"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Preview as Visitor</span>
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => handleLinkClick('commission-inquiry')}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 shadow-lg shadow-violet-700/25 transition-all flex items-center gap-1.5 cursor-pointer hover:scale-102 active:scale-98 min-h-[40px]"
              >
                <span>Request a Commission</span>
              </button>
            )}

            <button
              type="button"
              onClick={isOwner ? disableOwner : openLoginModal}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer min-w-[36px] min-h-[36px] flex items-center justify-center"
              title={isOwner ? 'Exit Creator Mode' : 'Creator Portal Access'}
              aria-label="Creator Login"
            >
              {isOwner ? <Unlock className="w-4 h-4 text-emerald-400" /> : <Lock className="w-3.5 h-3.5 opacity-60 hover:opacity-100" />}
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center gap-2">
            <button
              type="button"
              onClick={isOwner ? disableOwner : openLoginModal}
              className="p-2 rounded-xl bg-[#141221] border border-[#26223d] text-neutral-400 min-w-[36px] min-h-[36px] flex items-center justify-center"
              title="Creator Access"
              aria-label="Creator Access"
            >
              {isOwner ? <Unlock className="w-4 h-4 text-emerald-400" /> : <Lock className="w-3.5 h-3.5" />}
            </button>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-[#141221] border border-[#26223d] text-neutral-300 hover:text-white focus:outline-none min-w-[40px] min-h-[40px] flex items-center justify-center"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-3 p-4 rounded-2xl bg-[#110f1c] border border-[#2b2644] shadow-2xl backdrop-blur-xl animate-in fade-in slide-in-from-top-4 duration-200">
            <div className="flex flex-col gap-1.5">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleLinkClick(item.id)}
                    className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-colors text-left cursor-pointer ${
                      isActive
                        ? 'bg-violet-600 text-white font-semibold'
                        : 'text-neutral-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Icon className="w-4 h-4 text-violet-400" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
              <div className="pt-3 mt-2 border-t border-[#231e38] flex flex-col gap-2">
                {isOwner ? (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setMobileMenuOpen(false);
                        onOpenUploadModal();
                      }}
                      className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Upload Artwork</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        disableOwner();
                        setMobileMenuOpen(false);
                      }}
                      className="w-full py-2 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Preview as Clean Visitor</span>
                    </button>
                  </>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleLinkClick('commission-inquiry')}
                    className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center cursor-pointer"
                  >
                    Request a Commission
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
