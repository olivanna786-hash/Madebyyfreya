import React from 'react';
import { ArrowUp, Palette, Lock, Unlock } from 'lucide-react';
import { CONTACT_INFO } from '../data/portfolioData';
import { useOwner } from '../context/OwnerContext';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const { isOwner, openLoginModal, disableOwner } = useOwner();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="py-12 bg-[#06050a] border-t border-[#181424] text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-[#181424]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-violet-600 flex items-center justify-center font-bold text-white font-display text-sm">
              F
            </div>
            <div>
              <div className="font-bold text-white font-display text-sm tracking-wide">
                MadeByFreya
              </div>
              <p className="text-[11px] text-neutral-500">
                Digital Artist &amp; Character Illustrator
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-5">
            <button
              onClick={() => onNavigate('art-commissions')}
              className="text-violet-400 hover:text-violet-300 font-semibold flex items-center gap-1 cursor-pointer"
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Art Gallery</span>
            </button>
            <button
              onClick={() => onNavigate('about')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              About Freya
            </button>
            <button
              onClick={() => onNavigate('services')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Services
            </button>
            <button
              onClick={() => onNavigate('commission-inquiry')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Commissions
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Contact
            </button>
          </div>

          <button
            onClick={scrollToTop}
            className="p-2.5 rounded-xl bg-[#130f20] hover:bg-[#1a152b] border border-[#251f38] text-neutral-300 hover:text-white transition-colors flex items-center gap-1 cursor-pointer min-h-[40px]"
            aria-label="Back to top"
          >
            <ArrowUp className="w-4 h-4" />
            <span className="text-[11px] hidden sm:inline">Top</span>
          </button>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left text-[11px] text-neutral-500">
          <p>
            &copy; {new Date().getFullYear()} MadeByFreya. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <a
              href={CONTACT_INFO.instagram.url}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-neutral-300 transition-colors"
            >
              Instagram
            </a>
            <a
              href={CONTACT_INFO.tiktok.url}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-neutral-300 transition-colors"
            >
              TikTok
            </a>
            <a
              href={CONTACT_INFO.email.mailto}
              className="hover:text-neutral-300 transition-colors"
            >
              Email
            </a>
            <button
              type="button"
              onClick={isOwner ? disableOwner : openLoginModal}
              className="text-[10px] text-neutral-500 hover:text-violet-400 transition-colors flex items-center gap-1 cursor-pointer ml-2 border-l border-white/10 pl-3"
              title="Creator Studio Login"
            >
              {isOwner ? (
                <>
                  <Unlock className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400 font-semibold">Creator Active (Exit)</span>
                </>
              ) : (
                <>
                  <Lock className="w-3 h-3 opacity-60" />
                  <span>Creator Portal</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
