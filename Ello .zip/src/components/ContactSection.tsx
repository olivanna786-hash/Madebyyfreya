import React, { useState } from 'react';
import { Mail, Copy, Check, ExternalLink, MessageSquare, Instagram } from 'lucide-react';
import { CONTACT_INFO } from '../data/portfolioData';

export const ContactSection: React.FC = () => {
  const [discordCopied, setDiscordCopied] = useState<boolean>(false);
  const [emailCopied, setEmailCopied] = useState<boolean>(false);

  const copyDiscord = async () => {
    try {
      await navigator.clipboard.writeText(CONTACT_INFO.discord.username);
      setDiscordCopied(true);
      setTimeout(() => setDiscordCopied(false), 2500);
    } catch {}
  };

  const copyEmail = async () => {
    try {
      await navigator.clipboard.writeText(CONTACT_INFO.email.address);
      setEmailCopied(true);
      setTimeout(() => setEmailCopied(false), 2500);
    } catch {}
  };

  return (
    <section id="contact" className="py-20 sm:py-28 relative bg-[#09080e] border-t border-[#1f1b2e]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#181527] border border-violet-500/30 text-violet-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <Mail className="w-3.5 h-3.5 text-violet-400" />
            <span>Get in Touch</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight font-display text-white mb-3">
            LET&apos;S WORK TOGETHER.
          </h2>
          <p className="text-neutral-400 text-sm sm:text-base max-w-xl mx-auto leading-relaxed">
            Have an art commission, character concept, or project in mind?
            Reach out through your preferred channel below.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 max-w-5xl mx-auto">
          <a
            href={CONTACT_INFO.instagram.url}
            target="_blank"
            rel="noopener noreferrer"
            className="p-6 rounded-3xl bg-[#131022] border border-[#26203a] hover:border-pink-500/40 hover:bg-[#18142b] transition-all group flex flex-col justify-between cursor-pointer"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 text-white flex items-center justify-center mb-4 group-hover:scale-105 transition-transform shadow-lg shadow-rose-900/20">
                <Instagram className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
                Instagram
              </span>
              <h3 className="text-base font-bold text-white group-hover:text-pink-300 transition-colors mt-0.5">
                {CONTACT_INFO.instagram.username}
              </h3>
            </div>
            <div className="pt-4 mt-4 border-t border-[#201b31] flex items-center justify-between text-xs font-medium text-pink-400">
              <span>View Profile</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </div>
          </a>

          <a
            href={CONTACT_INFO.tiktok.url}
            target="_blank"
            rel="noopener noreferrer"
            className="p-6 rounded-3xl bg-[#131022] border border-[#26203a] hover:border-cyan-500/40 hover:bg-[#18142b] transition-all group flex flex-col justify-between cursor-pointer"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-white flex items-center justify-center mb-4 group-hover:scale-105 transition-transform shadow-lg shadow-cyan-900/20">
                <span className="font-black text-lg">TT</span>
              </div>
              <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
                TikTok
              </span>
              <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors mt-0.5">
                {CONTACT_INFO.tiktok.username}
              </h3>
            </div>
            <div className="pt-4 mt-4 border-t border-[#201b31] flex items-center justify-between text-xs font-medium text-cyan-400">
              <span>Watch Art Process</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </div>
          </a>

          <div className="p-6 rounded-3xl bg-[#131022] border border-[#26203a] hover:border-indigo-500/40 transition-all flex flex-col justify-between group">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-[#5865F2] text-white flex items-center justify-center mb-4 group-hover:scale-105 transition-transform shadow-lg shadow-indigo-900/20">
                <MessageSquare className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
                Discord Username
              </span>
              <h3 className="text-base font-bold text-white font-mono mt-0.5 select-all">
                {CONTACT_INFO.discord.username}
              </h3>
            </div>
            <div className="pt-4 mt-4 border-t border-[#201b31]">
              <button
                onClick={copyDiscord}
                className="w-full py-2 px-3 rounded-xl bg-[#201b33] hover:bg-[#2b2446] text-xs font-semibold text-indigo-300 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                {discordCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Username Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Discord Tag</span>
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-[#131022] border border-[#26203a] hover:border-violet-500/40 transition-all flex flex-col justify-between group">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-violet-600 to-purple-700 text-white flex items-center justify-center mb-4 group-hover:scale-105 transition-transform shadow-lg shadow-violet-900/20">
                <Mail className="w-6 h-6" />
              </div>
              <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
                Direct Email
              </span>
              <h3 className="text-xs sm:text-sm font-bold text-white font-mono mt-0.5 truncate select-all">
                {CONTACT_INFO.email.address}
              </h3>
            </div>
            <div className="pt-4 mt-4 border-t border-[#201b31] flex flex-col gap-1.5">
              <a
                href={CONTACT_INFO.email.mailto}
                className="w-full py-2 px-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-colors text-center"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Open Mail App</span>
              </a>
              <button
                onClick={copyEmail}
                className="text-[11px] text-neutral-400 hover:text-neutral-200 transition-colors text-center py-1 cursor-pointer"
              >
                {emailCopied ? 'Address copied to clipboard!' : 'Copy address'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
