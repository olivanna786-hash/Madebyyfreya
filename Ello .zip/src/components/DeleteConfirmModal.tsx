import React, { useState } from 'react';
import { Trash2, X, Loader2 } from 'lucide-react';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void | Promise<void>;
  itemTitle?: string;
  itemType?: string;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  itemTitle = 'this item',
  itemType = 'artwork',
}) => {
  const [isDeleting, setIsDeleting] = useState(false);

  if (!isOpen) return null;

  const handleConfirmClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setIsDeleting(true);
    try {
      await Promise.resolve(onConfirm());
    } catch (err) {
      console.error('Delete action failed:', err);
    } finally {
      setIsDeleting(false);
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-[99] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-150 select-none"
      onClick={(e) => {
        if (!isDeleting) {
          e.stopPropagation();
          onClose();
        }
      }}
    >
      <div
        className="relative w-full max-w-md bg-[#130f21] rounded-3xl border border-red-500/50 shadow-2xl shadow-red-950/60 p-6 sm:p-7 text-left"
        onClick={(e) => e.stopPropagation()}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="w-12 h-12 rounded-2xl bg-red-950/80 border border-red-500/50 text-red-400 flex items-center justify-center shadow-lg shadow-red-950/50">
            <Trash2 className="w-6 h-6 text-red-400" />
          </div>
          <button
            type="button"
            disabled={isDeleting}
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer disabled:opacity-50 min-w-[36px] min-h-[36px] flex items-center justify-center"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <h3 className="text-lg font-bold text-white mb-2 font-display">
          Delete {itemType.charAt(0).toUpperCase() + itemType.slice(1)}?
        </h3>
        <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mb-6">
          Are you sure you want to delete <span className="text-white font-semibold">&ldquo;{itemTitle}&rdquo;</span>?
          This will permanently remove it from your gallery.
        </p>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#231b34]">
          <button
            type="button"
            disabled={isDeleting}
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="px-4 py-2.5 rounded-xl text-xs font-semibold text-neutral-300 hover:text-white bg-[#1a142c] hover:bg-[#251e3e] transition-colors cursor-pointer min-h-[44px]"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={isDeleting}
            onClick={handleConfirmClick}
            className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 active:bg-red-700 text-white text-xs font-bold transition-all shadow-lg shadow-red-700/50 flex items-center gap-2 cursor-pointer hover:scale-102 active:scale-98 min-h-[44px]"
          >
            {isDeleting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Deleting...</span>
              </>
            ) : (
              <>
                <Trash2 className="w-4 h-4" />
                <span>Yes, Delete Artwork</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
