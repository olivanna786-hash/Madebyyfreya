import React from 'react';
import { Palette, Sparkles, Wand2, Eye, Heart, ArrowRight } from 'lucide-react';

interface AboutSectionProps {
  onNavigate: (sectionId: string) => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onNavigate }) => {
  const pillars = [
    {
      icon: Palette,
      title: 'Character Illustration',
      desc: 'Bringing original characters, RPG heroes, and avatars to life with striking expressions, dynamic poses, and rich lighting.',
    },
    {
      icon: Wand2,
      title: 'Fantasy & Gothic Realms',
      desc: 'Immersive atmospheric concepts featuring obsidian robes, celestial diadems, magical runes, and moody architectural backgrounds.',
    },
    {
      icon: Eye,
      title: 'Attention to Detail',
      desc: 'Meticulous brushwork, specular highlights, armor textures, and color harmony that ensures every piece captures viewer attention.',
    },
    {
      icon: Heart,
      title: 'Client Collaboration',
      desc: 'Working closely with commissioners through sketches, color flats, and final polish to ensure the artwork matches your exact vision.',
    },
  ];

  return (
    <section id="about" className="py-20 sm:py-28 relative bg-[#09080e]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Story */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#181527] border border-violet-500/30 text-violet-300 text-xs font-semibold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-violet-400" />
              <span>Meet Freya</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight font-display text-white leading-tight">
              BEHIND THE CANVAS.
            </h2>
            <p className="text-neutral-300 text-base sm:text-lg leading-relaxed">
              I&apos;m Freya, a digital artist and illustrator passionate about creating emotive character art and immersive fantasy worlds. Whether you&apos;re looking for a bespoke tabletop RPG portrait, a custom avatar, or striking dark fantasy concept art, I pour dedication into every brushstroke.
            </p>
            <p className="text-neutral-400 text-sm leading-relaxed">
              Every commission is tailored from the ground up to reflect your unique persona, story, and aesthetic preferences.
            </p>
            <div className="pt-4 flex flex-wrap gap-4">
              <button
                onClick={() => onNavigate('commission-inquiry')}
                className="px-6 py-3 rounded-2xl bg-white hover:bg-neutral-200 text-black font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-white/10"
              >
                <span>Request Commission</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onNavigate('art-commissions')}
                className="px-6 py-3 rounded-2xl bg-[#161324] hover:bg-[#1e1b30] text-violet-300 border border-[#2b2542] font-semibold text-xs tracking-wide transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>View Art Gallery</span>
              </button>
            </div>
          </div>

          {/* Right Column: Visual Pillars Grid */}
          <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {pillars.map((pillar, idx) => {
              const Icon = pillar.icon;
              return (
                <div
                  key={idx}
                  className="p-6 rounded-3xl bg-[#120f1e] border border-[#241f36] hover:border-violet-500/40 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-2xl bg-violet-600/20 text-violet-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform border border-violet-500/20">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm font-bold text-white mb-2 group-hover:text-violet-300 transition-colors font-display">
                    {pillar.title}
                  </h3>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {pillar.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
