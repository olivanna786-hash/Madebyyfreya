import { Artwork } from '../types';

export interface StoredCustomArtwork extends Artwork {
  imageBlob?: Blob;
}

export async function getAllArtworks(): Promise<Artwork[]> {
  try {
    const res = await fetch('/api/artworks');
    const contentType = res.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      const text = await res.text();
      console.warn('Server returned non-JSON response for artworks:', text.slice(0, 100));
      return [];
    }
    const data = await res.json();
    return data.artworks || [];
  } catch (err) {
    console.warn('Error fetching artworks from server:', err);
    return [];
  }
}

export async function saveArtwork(art: {
  id?: string;
  title: string;
  category: 'character' | 'portraits' | 'fantasy' | 'commissions';
  categoryLabel: string;
  description: string;
  imageBlob?: Blob;
  imageUrl?: string;
  status: string;
  aspectRatio: string;
  published?: boolean;
}): Promise<Artwork> {
  const formData = new FormData();
  if (art.id) formData.append('id', art.id);
  formData.append('title', art.title);
  formData.append('category', art.category);
  formData.append('categoryLabel', art.categoryLabel);
  formData.append('description', art.description);
  formData.append('status', art.status);
  formData.append('aspectRatio', art.aspectRatio);
  formData.append('published', String(art.published ?? true));

  if (art.imageBlob) {
    formData.append('imageFile', art.imageBlob, 'artwork.jpg');
  } else if (art.imageUrl) {
    formData.append('imageUrl', art.imageUrl);
  }

  const method = art.id && !art.id.startsWith('art_custom_') ? 'PUT' : 'POST';
  const url = art.id && method === 'PUT' ? `/api/artworks/${art.id}` : '/api/artworks';

  const res = await fetch(url, {
    method: art.id && method === 'PUT' ? 'PUT' : 'POST',
    body: formData,
  });

  const contentType = res.headers.get('content-type');
  if (!contentType || !contentType.includes('application/json')) {
    const text = await res.text();
    throw new Error(`Server returned invalid response (${res.status}): ${text.slice(0, 120)}`);
  }

  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'Failed to save artwork');
  }
  return data.artwork;
}

export async function updateArtworkPublishStatus(id: string, published: boolean): Promise<void> {
  const res = await fetch(`/api/artworks/${id}/publish`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ published }),
  });
  const contentType = res.headers.get('content-type');
  if (!contentType || !contentType.includes('application/json')) {
    throw new Error('Server returned non-JSON response when updating publish status.');
  }
  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'Failed to update publish status');
  }
}

export async function deleteArtwork(id: string): Promise<void> {
  const res = await fetch(`/api/artworks/${id}`, { method: 'DELETE' });
  const contentType = res.headers.get('content-type');
  if (!contentType || !contentType.includes('application/json')) {
    throw new Error('Server returned non-JSON response when deleting artwork.');
  }
  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'Failed to delete artwork');
  }
}

export async function getHomepageArtwork(): Promise<any> {
  try {
    const res = await fetch('/api/homepage-art');
    const contentType = res.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) return null;
    const data = await res.json();
    return data.homepageArt || null;
  } catch (err) {
    console.warn('Error fetching homepage artwork:', err);
    return null;
  }
}

export async function saveHomepageArtwork(payload: {
  targetType?: 'hero' | 'featured';
  imageBlob?: Blob;
  imageUrl?: string;
  featuredTitle?: string;
  featuredDescription?: string;
  featuredCategory?: string;
}): Promise<any> {
  const formData = new FormData();
  if (payload.targetType) formData.append('targetType', payload.targetType);
  if (payload.featuredTitle) formData.append('featuredTitle', payload.featuredTitle);
  if (payload.featuredDescription) formData.append('featuredDescription', payload.featuredDescription);
  if (payload.featuredCategory) formData.append('featuredCategory', payload.featuredCategory);

  if (payload.imageBlob) {
    formData.append('imageFile', payload.imageBlob, 'homepage-art.jpg');
  } else if (payload.imageUrl) {
    formData.append('imageUrl', payload.imageUrl);
  }

  const res = await fetch('/api/homepage-art', {
    method: 'POST',
    body: formData,
  });

  const contentType = res.headers.get('content-type');
  if (!contentType || !contentType.includes('application/json')) {
    const text = await res.text();
    throw new Error(`Server returned invalid response: ${text.slice(0, 100)}`);
  }

  const data = await res.json();
  if (!res.ok || !data.success) {
    throw new Error(data.error || 'Failed to save homepage artwork');
  }
  return data.homepageArt;
}
