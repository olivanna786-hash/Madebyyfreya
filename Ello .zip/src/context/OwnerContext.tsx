import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

interface OwnerContextType {
  isOwner: boolean;
  enableOwner: (pin?: string) => boolean;
  disableOwner: () => void;
  toggleOwner: () => void;
  isLoginModalOpen: boolean;
  openLoginModal: () => void;
  closeLoginModal: () => void;
  isChangePinModalOpen: boolean;
  openChangePinModal: () => void;
  closeChangePinModal: () => void;
  changePin: (newPin: string) => boolean;
  toastMessage: string | null;
  showToast: (msg: string, durationMs?: number) => void;
}

const OwnerContext = createContext<OwnerContextType | undefined>(undefined);

const OWNER_STORAGE_KEY = 'freya_owner_authenticated_v1';

export const OwnerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isOwner, setIsOwner] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem(OWNER_STORAGE_KEY);
      if (stored === null) {
        localStorage.setItem(OWNER_STORAGE_KEY, 'false');
        return false;
      }
      return stored === 'true';
    } catch {
      return false;
    }
  });

  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [isChangePinModalOpen, setIsChangePinModalOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string, durationMs: number = 3200) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, durationMs);
  }, []);

  const enableOwner = (pin: string = ''): boolean => {
    const clean = pin.trim();
    const currentCustomPin = (localStorage.getItem('freya_owner_pin') || '786').trim();
    if (clean === currentCustomPin) {
      setIsOwner(true);
      try {
        localStorage.setItem(OWNER_STORAGE_KEY, 'true');
      } catch (err) {
        console.warn('Could not save owner state:', err);
      }
      setIsLoginModalOpen(false);
      showToast('✨ Owner Mode Enabled - All Upload, Replace & Delete controls active');
      return true;
    }
    return false;
  };

  const changePin = (newPin: string): boolean => {
    const trimmed = newPin.trim();
    if (trimmed.length < 2) {
      return false;
    }
    try {
      localStorage.setItem('freya_owner_pin', trimmed);
      showToast('🔒 Creator PIN successfully updated and secured!');
      return true;
    } catch (err) {
      console.warn('Could not save new pin:', err);
      return false;
    }
  };

  const disableOwner = () => {
    setIsOwner(false);
    try {
      localStorage.setItem(OWNER_STORAGE_KEY, 'false');
    } catch (err) {
      console.warn('Could not clear owner state:', err);
    }
    showToast('👁️ Switched to Clean Visitor View - All owner controls hidden');
  };

  const toggleOwner = () => {
    setIsOwner((prev) => {
      const next = !prev;
      try {
        localStorage.setItem(OWNER_STORAGE_KEY, String(next));
      } catch (err) {
        console.warn('Could not save owner state:', err);
      }
      showToast(
        next
          ? '✨ Owner Mode Enabled - All Upload, Replace & Delete controls active'
          : '👁️ Switched to Clean Visitor View - All owner controls hidden'
      );
      return next;
    });
  };

  const openLoginModal = () => setIsLoginModalOpen(true);
  const closeLoginModal = () => setIsLoginModalOpen(false);
  const openChangePinModal = () => setIsChangePinModalOpen(true);
  const closeChangePinModal = () => setIsChangePinModalOpen(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'F' || e.key === 'f' || e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        toggleOwner();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <OwnerContext.Provider
      value={{
        isOwner,
        enableOwner,
        disableOwner,
        toggleOwner,
        isLoginModalOpen,
        openLoginModal,
        closeLoginModal,
        isChangePinModalOpen,
        openChangePinModal,
        closeChangePinModal,
        changePin,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </OwnerContext.Provider>
  );
};

export const useOwner = (): OwnerContextType => {
  const context = useContext(OwnerContext);
  if (!context) {
    throw new Error('useOwner must be used within an OwnerProvider');
  }
  return context;
};
