export interface Artwork {
  id: string;
  title: string;
  category: 'character' | 'portraits' | 'fantasy' | 'commissions';
  categoryLabel: string;
  description: string;
  imageUrl: string;
  status: string;
  aspectRatio: string;
  isCustom?: boolean;
  published?: boolean;
  order?: number;
}

export interface CommissionFormData {
  name: string;
  email: string;
  artworkType: string;
  description: string;
  budget: string;
  deadline: string;
  referenceUrl?: string;
}
