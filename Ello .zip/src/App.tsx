/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ArtGallery } from './components/ArtGallery';
import { CommissionForm } from './components/CommissionForm';
import { AboutSection } from './components/AboutSection';
import { ServicesSection } from './components/ServicesSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { UploadArtModal } from './components/UploadArtModal';
import { OwnerBanner } from './components/OwnerBanner';
import { OwnerLoginModal } from './components/OwnerLoginModal';
import { ChangePinModal } from './components/ChangePinModal';
import { OwnerProvider, useOwner } from './context/OwnerContext';
import { Artwork } from './types';
import { CheckCircle2 } from 'lucide-react';

function AppContent() {
  const { toastMessage, isChangePinModalOpen, closeChangePinModal } = useOwner();
  const [activeSection, setActiveSection] = useState<string>('hero');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState<boolean>(false);
  const [editTargetArt, setEditTargetArt] = useState<Artwork | null>(null);
  const [artRefreshTrigger, setArtRefreshTrigger] = useState<number>(0);

  const handleOpenUploadModal = (art?: Artwork | null) => {
    setEditTargetArt(art || null);
    setIsUploadModalOpen(true);
  };

  const handleArtSaved = () => {
    setArtRefreshTrigger((prev) => prev + 1);
  };

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const sections = [
        'hero',
        'art-commissions',
        'commission-inquiry',
        'about',
        'services',
        'contact',
      ];
      const scrollPosition = window.scrollY + 200;
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#09080e] text-[#f4f2fb] selection:bg-violet-600/30 selection:text-violet-200">
      <Navbar
        activeSection={activeSection}
        onNavigate={scrollToSection}
        onOpenUploadModal={() => handleOpenUploadModal(null)}
      />
      <main>
        <Hero
          onNavigate={scrollToSection}
          onOpenUploadModal={() => handleOpenUploadModal(null)}
          refreshTrigger={artRefreshTrigger}
        />
        <ArtGallery
          onRequestCommission={() => {
            const formElement = document.getElementById('commission-inquiry');
            if (formElement) {
              formElement.scrollIntoView({ behavior: 'smooth' });
            }
          }}
          refreshTrigger={artRefreshTrigger}
          onOpenUploadModal={handleOpenUploadModal}
        />
        <div className="bg-[#0b0913] pb-24 px-4 sm:px-6 lg:px-8">
          <CommissionForm />
        </div>
        <AboutSection onNavigate={scrollToSection} />
        <ServicesSection onNavigate={scrollToSection} />
        <ContactSection />
      </main>
      <Footer onNavigate={scrollToSection} />

      <UploadArtModal
        isOpen={isUploadModalOpen}
        onClose={() => {
          setIsUploadModalOpen(false);
          setEditTargetArt(null);
        }}
        onArtSaved={handleArtSaved}
        editTarget={editTargetArt}
      />

      <OwnerBanner onOpenUploadModal={() => handleOpenUploadModal(null)} />
      <OwnerLoginModal />
      <ChangePinModal
        isOpen={isChangePinModalOpen}
        onClose={closeChangePinModal}
      />

      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] bg-[#16112c]/95 border border-violet-500/60 backdrop-blur-xl px-5 py-3 rounded-2xl shadow-2xl shadow-violet-950/60 text-xs sm:text-sm text-white font-medium flex items-center gap-2.5 animate-in slide-in-from-top-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <OwnerProvider>
      <AppContent />
    </OwnerProvider>
  );
}
